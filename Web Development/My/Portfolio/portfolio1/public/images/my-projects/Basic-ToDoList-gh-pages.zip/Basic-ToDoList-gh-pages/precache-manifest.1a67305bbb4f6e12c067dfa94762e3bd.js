self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e1051feefe6754f4021c05c686b755f6",
    "url": "/Basic-ToDoList/index.html"
  },
  {
    "revision": "486ac1484814f1f26bb1",
    "url": "/Basic-ToDoList/static/css/main.ddd7dd0d.chunk.css"
  },
  {
    "revision": "fdbceb4f5212c9547301",
    "url": "/Basic-ToDoList/static/js/2.93377bc1.chunk.js"
  },
  {
    "revision": "0d6c4affe2a659999d44765f9a17cb4f",
    "url": "/Basic-ToDoList/static/js/2.93377bc1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "486ac1484814f1f26bb1",
    "url": "/Basic-ToDoList/static/js/main.641222c3.chunk.js"
  },
  {
    "revision": "33e96eee5e86e1934644",
    "url": "/Basic-ToDoList/static/js/runtime-main.c4096b20.js"
  }
]);